package com.example.projetolista

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
