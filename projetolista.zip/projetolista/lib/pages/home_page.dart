import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';


void main(){ 
  runApp( const HomePage());
}

class HomePage extends StatelessWidget{
     const HomePage({super.key});
     
       @override
       Widget build(BuildContext context) {
        return Scaffold(
          appBar: AppBar(title: const Text('aaaa queero ir falar com a ruiva')),
          body: ListView(
            children: [
              ListTile(
                leading: const CircleAvatar(child: Text('77')),

                title: const Text('Mas não sei se ela tem namorado , aaaah'),

                trailing: const Icon(Icons.chevron_right),

                onTap: () => Navigator.pushNamed(context, '/ex1-soma')
              ),
               ListTile(
                leading: const CircleAvatar(child: Text('12')),

                title: const Text('Mas não sei se ela tem namorado , aaaah'),

                trailing: const Icon(Icons.chevron_right),

                onTap: () => Navigator.pushNamed(context, '/ex1-soma')
              )
            ],
          ),
        );
       }
}

  