import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';


void main(){ 
  runApp( const Ex1SomaPage());
}

class Ex1SomaPage extends StatelessWidget{
     const Ex1SomaPage({super.key});
     
       @override
       Widget build(BuildContext context) {
        return Scaffold();
       }
       
}