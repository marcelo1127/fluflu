import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';
import 'package:projetolista/pages/ex1_soma_page.dart';
import 'package:projetolista/pages/home_page.dart';


void main(){ 
  runApp( const listaApp());
}

class listaApp extends StatelessWidget{
     const listaApp({super.key});
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
        title: 'Exercicios_liga_a_luz',
        theme: ThemeData(
         colorSchemeSeed: Colors.pinkAccent  
        ),
        initialRoute: '/',
        routes: {
          '/' : (context) => const HomePage(),


          '/ex1-soma' : (context) => const Ex1SomaPage(),
        }

    );
  }
}